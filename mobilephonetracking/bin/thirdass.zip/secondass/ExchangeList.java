package secondass;
import java.util.LinkedList;
public class ExchangeList {
	int i;

	public Exchange x;
	public Exchange r=new Exchange(0);
	public  LinkedList exchanges(){ 
		
	
		r.el.list.add(0);
	return r.el.list;
	
	}
	
	
	

}
