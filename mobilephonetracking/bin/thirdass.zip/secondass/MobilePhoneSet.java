package secondass;
import java.util.LinkedList;
public class MobilePhoneSet  {//stores mobilephone  objects of base station

MobilePhone p;
public LinkedList PhoneSet(){
	
	
	return p.ms.list;
}



}